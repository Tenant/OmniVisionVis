#include <fstream>
#include <iostream>
#include <string.h>
#include "velodynecalibinterface.h"

void VelodyneCalibInterface::loadInnerCalib(std::string filename)
{
    if(filename == "")
        return;

    std::ifstream calibfile;
    calibfile.open(filename.c_str());
    if (!calibfile.is_open())
        return;

    int id;
    int lineNum;
    calibfile >> lineNum;
    double rot_correction, vert_correction, dist_correction, vert_offset_correction, horiz_offset_correction;
    inner_calib.clear();
    for (int i = lineNum - 1; i >= 0; i--) {
        calibfile >> id >> rot_correction >> vert_correction >> dist_correction >> vert_offset_correction >> horiz_offset_correction;
        //std::cout << id << rot_correction << vert_correction << dist_correction << vert_offset_correction <<  horiz_offset_correction;
        inner_calib.push_back(VelodyneInnerCalib(lineNum, id, rot_correction, vert_correction, dist_correction, vert_offset_correction, horiz_offset_correction));
    }

    calibfile.close();
}

void VelodyneCalibInterface::loadOuterCalib(std::string filename)
{
    if(filename == "")
        return;

    std::ifstream calibfile;
    calibfile.open(filename.c_str());
    if (!calibfile.is_open())
        return;

    std::string header;
    double rot_x, rot_y, rot_z, shv_x, shv_y, shv_z;
    calibfile>>header>>rot_x>>rot_y>>rot_z;
    calibfile>>header>>shv_x>>shv_y>>shv_z;

    outer_calib.setCalibParams(shv_x, shv_y, shv_z, rot_x, rot_y, rot_z);
    calibfile.close();
}

VelodyneOuterCalib& VelodyneCalibInterface::getOuterCalib()
{
    return this->outer_calib;
}

std::vector<VelodyneInnerCalib>& VelodyneCalibInterface::getInnerCalib()
{
    return this->inner_calib;
}


