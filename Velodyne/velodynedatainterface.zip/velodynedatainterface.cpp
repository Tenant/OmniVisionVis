#include "velodynedatainterface.h"
#include <cmath>
#include <cstring>
#include <ctime>
#include <algorithm>
VelodyneDataInterface::VelodyneDataInterface()
{
    offset = 24;
    frameSize = 1264;
    headerSize = 16;
    //skip = 181;
	skip = 180;
    curFrameIndex = 0;
    scale = 0.001;

    startAngle = 0;
    stopAngle = 360;


}
VelodyneDataInterface::~VelodyneDataInterface()
{
    if (velodyne_file.is_open())
        velodyne_file.close();
}

VelodyneDataInterface::VelodyneDataInterface(std::string inner_calib_filename, std::string out_calib_filename)
{
    loadCalibParams(inner_calib_filename, out_calib_filename);

    //offset = 24;
    //frameSize = 1264;
    //headerSize = 16;
    //skip = 180;
    //curFrameIndex = 0;
    //scale = 0.001;

	offset = 24;
	frameSize = 1264;
	headerSize = 16;
	skip = 580;
	curFrameIndex = 0;
	scale = 0.001;

    startAngle = 0 ;
    stopAngle = 360;
}

void VelodyneDataInterface::setRange(double start_angle, double stop_angle)
{
    this->startAngle = start_angle;
    this->stopAngle = stop_angle;
}

void VelodyneDataInterface::getRange(double& start_angle, double& stop_angle)
{
     start_angle = this->startAngle;
     stop_angle = this->stopAngle;
}

void VelodyneDataInterface::loadCalibParams(std::string inner_calib_filename, std::string out_calib_filename)
{
    calib.loadInnerCalib(inner_calib_filename);
    calib.loadOuterCalib(out_calib_filename);
}

bool VelodyneDataInterface::loadData(std::string filename)
{
    if(filename == "")
        return 0;

    velodyne_file.open(filename.c_str(), std::ios_base::in | std::ios_base::binary);
    if (!velodyne_file.is_open())
        return 0;

    return 1;
}

bool VelodyneDataInterface::getFrame(long long &timestamp, long long &timestamp_utc,
                                     std::vector<ColoredPoint3d> &points,  std::vector<double>& dist,
                                     bool output_dist)
{
    char *data = new char[frameSize - headerSize];;

    if(output_dist)
        dist.clear();

    points.clear();

    std::vector<VelodyneInnerCalib> InnerCalib = this->calib.getInnerCalib();
    VelodyneOuterCalib OuterCalib = this->calib.getOuterCalib();

    for (int k=0; k<skip; k++){

        if (velodyne_file.eof())
        {
            if (data)
                delete [] data;
            return 0;
        }



        long long postion = (long long)offset + frameSize * (long long)(curFrameIndex+k);
        //velodyne_file.seekg(postion, std::ios_base::beg);
        velodyne_file.seekg(postion);

        int sec, usec, caplen, len;
        velodyne_file.read((char*)&sec, sizeof(sec));
        velodyne_file.read((char*)&usec, sizeof(usec));
        velodyne_file.read((char*)&caplen, sizeof(caplen));
        velodyne_file.read((char*)&len, sizeof(len));

        //转为UTC时间
        struct tm *p_tm;
        time_t timep(sec);
        p_tm = localtime(&timep);
        timestamp = ((p_tm->tm_hour*60 + p_tm->tm_min)*60 + p_tm->tm_sec) * 1000 + usec / 1000;
        timestamp_utc = timestamp;
        //velodyne_file.read(data, sizeof(char) * (frameSize - headerSize));
        //tahe
        unsigned int timestamp_gps;
        velodyne_file.read(data, sizeof(char) * (frameSize - headerSize-6));
        velodyne_file.read((char*)&timestamp_gps, sizeof(unsigned int));
        timestamp = timestamp_gps;

        //tahe
        ColoredPoint3d onergbpt;
        point3d onepoint;

        for (int i = 0; i < 12; i++) {
            int blockStart = i * 100 + 42;
            int blockId = (unsigned char)data[blockStart] + (unsigned char)data[blockStart + 1] * 0x100;
            int rotationData =  (unsigned char)data[blockStart + 2] + (unsigned char)data[blockStart + 3] * 0x100;

//            double start = (startAngle + calib.getOuterCalib().rot.z/M_PI*180)*100;
//            double stop = (stopAngle + calib.getOuterCalib().rot.z/M_PI*180)*100;

            double start;
            double stop;

            if (stopAngle < startAngle)
            {
                stop = (stopAngle) *100;
                start = (startAngle )*100;
                if (!(((rotationData>=start)&&(rotationData<=36000)) || ((rotationData>=0)&&(rotationData<=stop))))
                    continue;
            }
            else{
                start = (startAngle )*100;
                stop = (stopAngle )*100;
                if (rotationData<start || rotationData>stop)
                    continue;
            }

            //rotationData += 18000;

            double theta = rotationData / 18000.0 * 3.1415926535;
            for (int j = 0; j < 32; j++) {
                int blockOffset = (blockId == 0xEEFF ? 0 : 32);
                int distanceData = (unsigned char)data[blockStart + 4 + j * 3] + (unsigned char)data[blockStart + 5 + j * 3] * 0x100;
                if (distanceData == 0) {
                    continue;
                }

                double distance = distanceData * 2. + InnerCalib[j + blockOffset].dist_correction;
                distance *= scale;

                double cosVertAngle = cos(InnerCalib[j + blockOffset].vert_correction);
                double sinVertAngle = sin(InnerCalib[j + blockOffset].vert_correction);
                double cosRotCorrection = cos(InnerCalib[j + blockOffset].rot_correction);
                double sinRotCorrection = sin(InnerCalib[j + blockOffset].rot_correction);

                double cosRotAngle = cos(theta) * cosRotCorrection + sin(theta) * sinRotCorrection;
                double sinRotAngle = sin(theta) * cosRotCorrection - cos(theta) * sinRotCorrection;


                double hOffsetCorr = InnerCalib[j + blockOffset].horiz_offset_correction * scale;
                double vOffsetCorr = InnerCalib[j + blockOffset].vert_offset_correction * scale;

                double xyDistance = distance * cosVertAngle - vOffsetCorr * sinVertAngle;

                //onept.r = onept.g = onept.b = 0;
                onepoint.x = xyDistance * sinRotAngle - hOffsetCorr * cosRotAngle;
                onepoint.y = xyDistance * cosRotAngle + hOffsetCorr * sinRotAngle;
                onepoint.z = distance * sinVertAngle + vOffsetCorr * cosVertAngle;

                //转到GPS坐标系
                rotatePoint3d(onepoint, OuterCalib.rot_mat);
                //shiftPoint3d(onepoint, OuterCalib.shift);
                //
                onergbpt.x = onepoint.x;
                onergbpt.y = onepoint.y;
                onergbpt.z = onepoint.z;

                double min_z = -3, max_z = -0.1;
                double tmp = (onergbpt.z - min_z)/(max_z - min_z)*255;
                onergbpt.color[2] = std::max<double>(0,std::min<double>(255,tmp));

                onergbpt.color[0] = 255 - onergbpt.color[2];
                if (onergbpt.color[2] >= 128)
                    onergbpt.color[1] = onergbpt.color[0] *2;
                else
                    onergbpt.color[1] = onergbpt.color[2] *2;

                points.push_back(onergbpt);

                if (output_dist)
                    dist.push_back(distance);
            }
        }
    }

    curFrameIndex += skip;

    if (data)
        delete [] data;
    return 1;
}

bool VelodyneDataInterface::getFrame(long long &timestamp, long long &timestamp_utc, std::vector<ColoredPoint3d> &points,
                                     std::vector<double>& dist, bool output_dist, bool useintense)

{

    char *data =new char[frameSize - headerSize];



    if(output_dist)

        dist.clear();



    points.clear();



    std::vector<VelodyneInnerCalib> InnerCalib = this->calib.getInnerCalib();

    VelodyneOuterCalib OuterCalib = this->calib.getOuterCalib();



    for (int k=0; k<skip; k++){



        if (velodyne_file.eof())

        {

            if (data)

                delete [] data;

            return 0;

        }



        long long postion = (long long)offset + frameSize * (long long)(curFrameIndex+k);

        //velodyne_file.seekg(postion, std::ios_base::beg);

        velodyne_file.seekg(postion);



        int sec, usec, caplen, len;

        velodyne_file.read((char*)&sec, sizeof(sec));

        velodyne_file.read((char*)&usec, sizeof(usec));

        velodyne_file.read((char*)&caplen, sizeof(caplen));

        velodyne_file.read((char*)&len, sizeof(len));



        //转为UTC时间

        struct tm *p_tm;

        time_t timep(sec);

        p_tm = localtime(&timep);

        timestamp = ((p_tm->tm_hour*60 + p_tm->tm_min)*60 + p_tm->tm_sec)*1000 + usec/1000;

        timestamp_utc = timestamp;

        //velodyne_file.read(data, sizeof(char) * (frameSize - headerSize));

        //tahe

        unsigned int timestamp_gps;

        velodyne_file.read(data, sizeof(char) * (frameSize - headerSize-6));

        velodyne_file.read((char*)&timestamp_gps, sizeof(unsigned int));

        timestamp = timestamp_gps;



        //tahe

        ColoredPoint3d onergbpt;

        point3d onepoint;



        for (int i = 0; i < 12; i++) {

            int blockStart = i * 100 + 42;

            int blockId = (unsigned char)data[blockStart] + (unsigned char)data[blockStart + 1] * 0x100;

            int rotationData =  (unsigned char)data[blockStart + 2] + (unsigned char)data[blockStart + 3] * 0x100;



//            double start = (startAngle + calib.getOuterCalib().rot.z/M_PI*180)*100;

//            double stop = (stopAngle + calib.getOuterCalib().rot.z/M_PI*180)*100;



            double start;

            double stop;



            if (stopAngle < startAngle)

            {

                stop = (stopAngle) *100;

                start = (startAngle )*100;

                if (!(((rotationData>=start)&&(rotationData<=36000)) || ((rotationData>=0)&&(rotationData<=stop))))

                    continue;

            }

            else{

                start = (startAngle )*100;

                stop = (stopAngle )*100;

                if (rotationData<start || rotationData>stop)

                    continue;

            }



            //rotationData += 18000;



            double theta = rotationData / 18000.0 * 3.1415926535;

            for (int j = 0; j < 32; j++) {

                int blockOffset = (blockId == 0xEEFF ? 0 : 32);

                int distanceData = (unsigned char)data[blockStart + 4 + j * 3] + (unsigned char)data[blockStart + 5 + j * 3] * 0x100;

                int intense=(unsigned char)data[blockStart + 6 + j * 3];

                if (distanceData == 0) {

                    continue;

                }



                double distance = distanceData * 2. + InnerCalib[j + blockOffset].dist_correction;

                distance *= scale;



                double cosVertAngle = cos(InnerCalib[j + blockOffset].vert_correction);

                double sinVertAngle = sin(InnerCalib[j + blockOffset].vert_correction);

                double cosRotCorrection = cos(InnerCalib[j + blockOffset].rot_correction);

                double sinRotCorrection = sin(InnerCalib[j + blockOffset].rot_correction);



                double cosRotAngle = cos(theta) * cosRotCorrection + sin(theta) * sinRotCorrection;

                double sinRotAngle = sin(theta) * cosRotCorrection - cos(theta) * sinRotCorrection;





                double hOffsetCorr = InnerCalib[j + blockOffset].horiz_offset_correction * scale;

                double vOffsetCorr = InnerCalib[j + blockOffset].vert_offset_correction * scale;



                double xyDistance = distance * cosVertAngle - vOffsetCorr * sinVertAngle;



                //onept.r = onept.g = onept.b = 0;

                onepoint.x = xyDistance * sinRotAngle - hOffsetCorr * cosRotAngle;

                onepoint.y = xyDistance * cosRotAngle + hOffsetCorr * sinRotAngle;

                onepoint.z = distance * sinVertAngle + vOffsetCorr * cosVertAngle;



                //转到GPS坐标系

                rotatePoint3d(onepoint, OuterCalib.rot_mat);

                //shiftPoint3d(onepoint, OuterCalib.shift);

                //

                onergbpt.x = onepoint.x;

                onergbpt.y = onepoint.y;

                onergbpt.z = onepoint.z;



                double min_z = -3, max_z = -0.1;

                double tmp = (onergbpt.z - min_z)/(max_z - min_z)*255;

                if(!useintense){

                    onergbpt.color[2] = std::max<double>(0,std::min<double>(255,tmp));



                    onergbpt.color[0] = 255 - onergbpt.color[2];

                    if (onergbpt.color[2] >= 128)

                        onergbpt.color[1] = onergbpt.color[0] *2;

                    else

                        onergbpt.color[1] = onergbpt.color[2] *2;

                }

                else{

                    double min_intense =0, max_intense = 30;

                        double tmp_intense = (intense - min_intense)/(max_intense - min_intense)*255;

                        onergbpt.color[2] = std::max<double>(0,std::min<double>(255,tmp_intense));



                        onergbpt.color[0] = 255 - onergbpt.color[2];

                        if (onergbpt.color[2] >= 128)

                            onergbpt.color[0] = onergbpt.color[0] *2;

                        else

                            onergbpt.color[0] = onergbpt.color[2] *2;

                }



                points.push_back(onergbpt);



                if (output_dist)

                    dist.push_back(distance);

            }

        }

    }



    curFrameIndex += skip;



    if (data)

        delete [] data;

    return 1;

}
