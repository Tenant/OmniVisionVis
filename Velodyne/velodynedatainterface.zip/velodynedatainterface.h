#ifndef VELODYNEDATAINTERFACE_H
#define VELODYNEDATAINTERFACE_H
#include <fstream>
#include "velodynecalibinterface.h"
#include "../misc.h"

class VelodyneDataInterface
{
public:
    VelodyneDataInterface();
    ~VelodyneDataInterface();
    VelodyneDataInterface(std::string inner_calib_filename, std::string out_calib_filename);

public:
    void loadCalibParams(std::string inner_calib_filename, std::string out_calib_filename);
    bool loadData(std::string filename);

    bool getFrame(long long &timestamp, long long &timestamp_utc, std::vector<ColoredPoint3d> &points,
                  std::vector<double>& dist, bool output_dist);
    bool getFrame(long long &timestamp, long long &timestamp_utc, std::vector<ColoredPoint3d> &points,
                  std::vector<double>& dist, bool output_dist, bool useintense);

    void setRange(double start_angle, double stop_angle);
    void getRange(double& start_angle, double& stop_angle);
private:
    VelodyneCalibInterface calib;
    std::ifstream velodyne_file;
    long long frameNum;
    int curFrameIndex;
    int skip;
    int offset;
    int headerSize;
    int frameSize;

    double startAngle;
    double stopAngle;
    double scale;
};

#endif // VELODYNEDATAINTERFACE_H
